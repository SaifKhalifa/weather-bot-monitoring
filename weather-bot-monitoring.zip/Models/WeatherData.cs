namespace weather_bot_monitoring.Models;
public class WeatherData
{
    public string Location { get; set; }
    public double Temperature { get; set; }
    public double Humidity { get; set; }
}